struct edge {
    edge *next;
    int t,x,v,c;
    bool im,bfim;
} ES[MAXM],*V[MAXN];
struct tr{
    tr(){}
    tr(int tt,edge *te){
        t=tt;
        e=te;
    }
    int t;
    edge *e;
};
bool operator < (const tr &a,const tr &b){
    return a.t<b.t;
}
vector<int> curRoad;//Ѱ��·��dfsʱ��¼
vector<vector<int> >relRoad;//����𰸣���¼����·��
vector<int>mustChoose;//��¼һ����Ҫѡ��ĵ�ı��
map<unsigned long long,int>mp;//��¼�Ѿ�������Ĵ�
set<tr>myTree[MAXN];//mark the tree used in simplex
char topo_file[20000];//������

int bb[MAXN];//the same as the array b
int ww[MAXN];//the same as the array w
bool vis[MAXN];
int EC=-1;
int links[50500][4];
int consumptionNodes[505][3];
void getMustChoose(){
    return;
}
//..xt:��bitset����hash��ȡ
unsigned long long getHash(bitset<BITSIZE>&gene) {
    char hashStr[2000];
    int tmpChar=0;
    int pos=0;
    for(int i=0; i<nodesNum; i++) {
        tmpChar<<=1;
        tmpChar|=gene[i];
        if(i%4==0) {
            hashStr[pos++]=(char)(tmpChar+'a'-1);
            tmpChar=0;
        }
    }
    if(tmpChar)hashStr[pos++]=(char)(tmpChar+'a'-1);
    unsigned long long seed = 131; // 31 131 1313 13131 131313 etc..
    unsigned long long hash = 0;
    char *str=hashStr;
    while (*str) {
        hash = hash * seed + (*str++);
    }
    return hash;
}
//..xt:���ӱߵĺ���
void addedge(int a,int b,int v,bool im,int x,int c=INF) {
    edge e1= {V[a],b,x,v,c,im,im};
    ES[++EC]=e1;
    V[a]=&ES[EC];
    if(im){
        myTree[a].insert(tr(b,V[a]));
        myTree[b].insert(tr(a,V[a]));
    }
}
//..xt:��ȡ����
void readData(char *topo[],int nodesNum,int linkNum,int clientNum) {
    int lineAdd=4,numAdd=1;
    int st,ed,bandW,cost;
    for(int i=0; i<linkNum; i++) {
        sscanf(topo[i+lineAdd],"%d%d%d%d",&st,&ed,&bandW,&cost);
        links[i][0]=st;
        links[i][1]=ed;
        links[i][2]=bandW;
        links[i][3]=cost;
    }
    lineAdd=linkNum+5;
    numAdd+=nodesNum;
    int n_client,n_node,need;
    for(int i=0; i<clientNum; i++) {
        sscanf(topo[i+lineAdd],"%d%d%d",&n_client,&n_node,&need);
        consumptionNodes[i][0]=n_client;
        consumptionNodes[i][1]=n_node;
        consumptionNodes[i][2]=need;
    }
}
//..xt:��ͼ����
//..xt:����ڵ��ţ�1...nodesNum
//..xt:���ѽڵ��ţ�nodesNum+1...nodesNum+clientNum
//..xt:�������ӳ���Դ��
void buildBasicGraph() {
    if(EC>=0) {
        for(int i=0;i<=nodesNum+clientNum+1;i++)myTree[i].clear();
        for(int i=0;i<=nodesNum+clientNum+1;i++){
            for(edge *j=V[i];j;j=j->next){
                j->im=j->bfim;
                if(j->im){
                    j->x=j->c;
                    myTree[i].insert(tr(j->t,j));
                    myTree[j->t].insert(tr(i,j));
                }
                else{
                    j->x=0;
                }
            }
        }
        return;
    }
    EC=-1;
    int numAdd=1;
    int st,ed,bandW,cost;
    //add edges from 0 to nodes
    for(int i=0; i<nodesNum; i++) {
        addedge(0,i+1,0,false,0,0);
    }
    //add the internal edges(two directions)
    for(int i=0; i<linkNum; i++) {
        st=links[i][0];
        ed=links[i][1];
        bandW=links[i][2];
        cost=links[i][3];
        st+=numAdd;
        ed+=numAdd;
        addedge(st,ed,cost,false,0,bandW);
        addedge(ed,st,cost,false,0,bandW);
    }
    //add edges from nodes to clients
    numAdd+=nodesNum;
    int n_client,n_node,need,tmp_sum=0;
    for(int i=0; i<clientNum; i++) {
        n_client=consumptionNodes[i][0];
        n_node=consumptionNodes[i][1];
        need=consumptionNodes[i][2];
        n_node++;
        n_client+=numAdd;
        addedge(n_node,n_client,0,false,0);
        tmp_sum+=need;
        bb[n_client]=-need;
    }
    bb[0]=tmp_sum;
    //add edges between the add_node and other nodes
    //add_node's number is nodesNum+clientNum+1

    int MM=(nodesNum+clientNum+1)*100/2+5;
    for(int i=0;i<=nodesNum+clientNum;i++){
        if(bb[i]>0)addedge(i,nodesNum+clientNum+1,MM,true,bb[i],bb[i]);
        else addedge(nodesNum+clientNum+1,i,MM,true,-bb[i],-bb[i]);
    }

}
//..xt:�ı�ĳ����·������
void setCapacity(int st,int ed,int c) {
    for(edge *k=V[st]; k; k=k->next) {
        if(k->t==ed) {
            k->c=c;
            break;
        }
    }
}
void calWw(int pos){
    set<tr>::iterator it;
    vis[pos]=true;
    for(it=myTree[pos].begin();it!=myTree[pos].end();it++){
        if(!vis[it->t]){
            if(it->e->t==pos)ww[it->t]=ww[pos]+ it->e->v;
            else ww[it->t]=ww[pos]- it->e->v;
            calWw(it->t);
        }
    }
}
int now_st,now_ed;
//..xt: find the enterEdge return the pointer
edge *findEnterEdge(){
    for(int i=0;i<=nodesNum+clientNum+1;i++){
        for(edge *j=V[i];j;j=j->next){
            if(j->im||j->c==0)continue;
            if(j->x==0&& j->v-ww[i]+ww[j->t]<0){
                now_st=i;
                now_ed=j->t;
                return j;
            }
            if(j->x==j->c&& j->v-ww[i]+ww[j->t]>0){
                now_st=i;
                now_ed=j->t;
                return j;
            }
        }
    }
    return NULL;
}
bool inCircle[MAXN];
int myRoad[MAXN],nodesNumInRoad;

int getMinFlow(int pos,int p,int step,int mmin){
    //printf("pos=%d mmin=%d\n",pos,mmin);
    set<tr>::iterator it;
    myRoad[step]=pos;
    vis[pos]=true;
    if(pos==p){
        nodesNumInRoad=step;
        for(int i=0;i<=step;i++){
            inCircle[myRoad[i]]=true;
        }
        return mmin;
    }
    for(it=myTree[pos].begin();it!=myTree[pos].end();it++){
        edge *tmpe=it->e;
        //cout << "t=" << (it->e->t) << endl;
        if(!vis[it->t]){
            int tmpRel;
            if(tmpe->t==pos){//the opposite direction
                tmpRel=getMinFlow(it->t,p,step+1,min(mmin,tmpe->x));
            }
            else{
                tmpRel=getMinFlow(it->t,p,step+1,min(mmin,tmpe->c-tmpe->x));
            }
            if(nodesNumInRoad>0)return tmpRel;
        }
    }
    return 0;
}
int getFirstNodes(int pos){
    if(inCircle[pos])return pos;
    vis[pos]=true;
    set<tr>::iterator it;
    for(it=myTree[pos].begin();it!=myTree[pos].end();it++){
        int num;
        if(!vis[it->t]){
            num=getFirstNodes(it->t);
            if(num)return num;
        }
    }
    return 0;
}
edge *getOutEdge(int firstNodes,int p,int q,int mmin,edge *enterEdge){
    bool ok=false;
    for(int i=0;i<=nodesNumInRoad;i++){
        if(!ok)ok=(myRoad[i]==firstNodes);
        if(ok){
            if(i!=nodesNumInRoad){
                edge *tmpt=myTree[myRoad[i]].find(tr(myRoad[i+1],NULL))->e;
                if(tmpt->t==myRoad[i]){
                    if(tmpt->x==mmin){
                        now_st=myRoad[i];
                        now_ed=myRoad[i+1];
                        return tmpt;
                    }
                }
                else{
                    if(tmpt->c-tmpt->x==mmin){
                        now_st=myRoad[i];
                        now_ed=myRoad[i+1];
                        return tmpt;
                    }
                }
            }
        }
    }
    if(enterEdge->c==mmin){
        now_st=p;
        now_ed=q;
        return enterEdge;
    }
    for(int i=0;i<nodesNumInRoad;i++){
        edge *tmpt=myTree[myRoad[i]].find(tr(myRoad[i+1],NULL))->e;
        if(tmpt->t==myRoad[i]){
            if(tmpt->x==mmin){
                now_st=myRoad[i];
                now_ed=myRoad[i+1];
                return tmpt;
            }
        }
        else{
            if(tmpt->c-tmpt->x==mmin){
                now_st=myRoad[i];
                now_ed=myRoad[i+1];
                return tmpt;
            }
        }
    }
}
void changeFlowsInMyTree(int minFlow){
    set<tr>::iterator it;
    for(int i=0;i<nodesNumInRoad;i++){
        it=myTree[myRoad[i]].find(tr(myRoad[i+1],NULL));
        if(it==myTree[myRoad[i]].end()){
            while(true)printf("changeFlowsInMyTree error\n");
        }
        edge *e=it->e;
        if(e->t==myRoad[i])e->x-=minFlow;
        else e->x+=minFlow;
    }
}
int giveRel(){
    int rel=0,num=0;
    for(int i=1;i<=nodesNum+clientNum;i++){
        for(edge *it=V[i];it;it=it->next){
            if(it->t==nodesNum+clientNum+1)continue;
            rel+=it->x*it->v;
        }
    }
    for(edge *it=V[nodesNum+clientNum+1];it;it=it->next){
        if(it->t>nodesNum && it->t<=nodesNum+clientNum && it->x!=0){
            num++;
        }
    }
    //printf("num=%d\n",num);
    return rel+num*deployCost;
}
void printTree(){
    set<tr>::iterator it;
    for(int i=0;i<=nodesNum+clientNum+1;i++){
        printf("root %d ",i);
        for(it=myTree[i].begin();it!=myTree[i].end();it++){
            printf("%d ",it->t);
        }
        puts("");
    }
}
//..xt: give the answer
int maxcostflow() {
    //printf("danwei=%d\n",deployCost);
    ww[nodesNum+clientNum+1]=0;
    memset(vis,0,sizeof(vis));
    calWw(nodesNum+clientNum+1);
    edge *enterEdge=findEnterEdge();
    do{
        int p=now_st;
        int q=now_ed;
        if(enterEdge->x==enterEdge->c)swap(p,q);
        memset(vis,0,sizeof(vis));
        memset(inCircle,0,sizeof(inCircle));
        nodesNumInRoad=0;
        int minFlow=getMinFlow(q,p,0,INF);
        minFlow=min(minFlow,enterEdge->c);
        memset(vis,0,sizeof(vis));
        int firstNodes=getFirstNodes(nodesNum+clientNum+1);
        edge *outEdge=getOutEdge(firstNodes,p,q,minFlow,enterEdge);
        if(enterEdge->x==0)enterEdge->x+=minFlow;
        else enterEdge->x-=minFlow;
        memset(vis,0,sizeof(vis));
        changeFlowsInMyTree(minFlow);
        if(enterEdge!=outEdge){
            myTree[now_st].erase(tr(now_ed,NULL));
            myTree[now_ed].erase(tr(now_st,NULL));
            myTree[p].insert(tr(q,enterEdge));
            myTree[q].insert(tr(p,enterEdge));
        }
        ww[nodesNum+clientNum+1]=0;
        memset(vis,0,sizeof(vis));
        calWw(nodesNum+clientNum+1);
        enterEdge=findEnterEdge();
    }while(enterEdge);
    return giveRel();
}
int calCost(bitset<BITSIZE>gene,int mustCal) {
    //puts("jinru");
    unsigned long long relHash=getHash(gene);
    if((!mustCal)&&mp.find(relHash)!=mp.end())return mp[relHash];
    //puts("jinru2");
    buildBasicGraph();
    int numAdd=1;
    for(int i=0; i<nodesNum; i++) {
        if(gene[i]) {
            setCapacity(0,i+numAdd,INF);
        } else {
            setCapacity(0,i+numAdd,0);
        }
    }
    //printf("num=%d\n",gene.count());
    int costRel=maxcostflow()+gene.count()*deployCost;
    //printf("costRel=%d\n",costRel);
    return mp[relHash]=costRel;
}
